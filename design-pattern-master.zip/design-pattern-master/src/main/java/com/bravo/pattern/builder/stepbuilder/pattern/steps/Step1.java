package com.bravo.pattern.builder.stepbuilder.pattern.steps;

public interface Step1 {
    Step2 step1(String part1);
}
