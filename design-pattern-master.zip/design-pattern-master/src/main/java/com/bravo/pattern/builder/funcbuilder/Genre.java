package com.bravo.pattern.builder.funcbuilder;

public enum Genre {
    FANTASY/*奇幻，比如《哈利·波特》*/,
    HORROR /*恐怖*/,
    SCI_FI /*科幻，比如《80天环游世界》*/;
}