package com.bravo.pattern.builder.stepbuilder.pattern.steps;

public interface Step3 {
    BuildStep step3(String part3);
}