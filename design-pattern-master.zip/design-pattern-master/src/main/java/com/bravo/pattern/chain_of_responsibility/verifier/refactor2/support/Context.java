package com.bravo.pattern.chain_of_responsibility.verifier.refactor2.support;

import lombok.Data;

@Data
public class Context {

    private OrderConvertRequest request;

    // 其他过程参数

}