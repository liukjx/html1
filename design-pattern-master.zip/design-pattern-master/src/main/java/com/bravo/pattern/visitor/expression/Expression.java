package com.bravo.pattern.visitor.expression;

public interface Expression {
    int interpret();
}