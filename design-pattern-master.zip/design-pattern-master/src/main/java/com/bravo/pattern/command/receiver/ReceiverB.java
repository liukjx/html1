package com.bravo.pattern.command.receiver;

public class ReceiverB {
    public void receiverMethod() {
        System.out.println("调用ReceiverB的方法");
    }
}