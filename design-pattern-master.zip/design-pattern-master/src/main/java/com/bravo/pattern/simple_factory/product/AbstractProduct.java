package com.bravo.pattern.simple_factory.product;

public class AbstractProduct {

}