package com.bravo.pattern.factory_method.pattern.product;

public class BProduct extends AbstractProduct {

}