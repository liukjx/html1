package com.bravo.pattern.simple_factory.product;

public class AProduct extends AbstractProduct {

}