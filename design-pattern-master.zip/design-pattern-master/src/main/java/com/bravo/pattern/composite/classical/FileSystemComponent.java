package com.bravo.pattern.composite.classical;

// 抽象组件类
interface FileSystemComponent {
    void display();
}