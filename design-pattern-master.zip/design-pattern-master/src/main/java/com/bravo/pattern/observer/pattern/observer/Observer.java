package com.bravo.pattern.observer.pattern.observer;

public interface Observer {

    void update(String phone, String product);
}
