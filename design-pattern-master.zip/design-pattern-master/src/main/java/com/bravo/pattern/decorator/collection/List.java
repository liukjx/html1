package com.bravo.pattern.decorator.collection;

// 省略List的独有方法
public interface List<E> extends Collection<E> {

}