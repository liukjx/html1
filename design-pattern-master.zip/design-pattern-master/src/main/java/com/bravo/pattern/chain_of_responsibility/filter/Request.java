package com.bravo.pattern.chain_of_responsibility.filter;

public class Request {
}