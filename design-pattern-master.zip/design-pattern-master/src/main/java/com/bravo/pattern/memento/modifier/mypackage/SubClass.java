package com.bravo.pattern.memento.modifier.mypackage;

// 包访问权限：只有myPackage包下的类才能访问SubClass
class SubClass {

}