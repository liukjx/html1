package com.bravo.pattern.mediator.java.colleague;

public interface User {
    void sendMessage(String message);
    void receiveMessage(String message);
}