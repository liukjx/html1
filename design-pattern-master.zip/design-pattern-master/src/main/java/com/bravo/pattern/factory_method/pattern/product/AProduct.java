package com.bravo.pattern.factory_method.pattern.product;

public class AProduct extends AbstractProduct {

}