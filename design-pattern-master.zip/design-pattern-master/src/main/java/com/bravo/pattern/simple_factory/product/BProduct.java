package com.bravo.pattern.simple_factory.product;

public class BProduct extends AbstractProduct {

}