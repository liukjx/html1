package com.bravo.pattern.builder.stepbuilder.pattern.steps;

public interface Step2 {
    Step3 step2(String part2);
}