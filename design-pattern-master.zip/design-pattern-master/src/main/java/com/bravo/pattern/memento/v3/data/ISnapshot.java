package com.bravo.pattern.memento.v3.data;

public interface ISnapshot {
    // 空接口
}