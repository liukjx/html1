package com.bravo.pattern.command.command;

public interface Command {

    void execute();
    
}