package com.bravo.pattern.iterator.v2.iterator;

public interface Iterable<T> {
    Iterator<T> iterator();
}