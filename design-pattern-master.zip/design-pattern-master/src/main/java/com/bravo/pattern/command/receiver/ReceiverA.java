package com.bravo.pattern.command.receiver;

public class ReceiverA {
    public void receiverMethod() {
        System.out.println("调用ReceiverA的方法");
    }
}