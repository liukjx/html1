package com.bravo.advanced.generics.genericclass;

public class User {
}