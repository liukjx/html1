package com.bravo.advanced.reflection.frameworktest;


import com.bravo.advanced.reflection.framework.BaseDao;

public class UserDao extends BaseDao<UserDO> {
}
