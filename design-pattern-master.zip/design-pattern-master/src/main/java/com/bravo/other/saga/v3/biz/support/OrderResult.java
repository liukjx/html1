package com.bravo.other.saga.v3.biz.support;

import lombok.Data;

@Data
public class OrderResult {
}
