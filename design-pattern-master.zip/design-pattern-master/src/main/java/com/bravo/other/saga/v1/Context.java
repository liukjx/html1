package com.bravo.other.saga.v1;

// 数据传递的上下文
public class Context {
    // 包含入参、各个步骤产生的数据等
}