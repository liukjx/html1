package com.bravo.other.aop;


public interface MethodInvocation {

    Object proceed() throws Throwable;

}
